package DependentPizzaStore;

public class Eggplant implements Veggies {

    @Override
    public String toString() {
        return "Eggplant";
    }
}
