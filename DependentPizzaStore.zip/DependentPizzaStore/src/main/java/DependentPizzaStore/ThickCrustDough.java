package DependentPizzaStore;

public class ThickCrustDough implements Dough {

    @Override
    public String toString() {
        return "ThickCrust style extra thick crust dough";
    }
}

