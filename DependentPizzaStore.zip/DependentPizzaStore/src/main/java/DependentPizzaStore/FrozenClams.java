package DependentPizzaStore;

public class FrozenClams implements Clams {

    @Override
    public String toString() {
        return "Frozen Clams from Chesapeake Bay";
    }
}
