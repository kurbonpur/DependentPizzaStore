package DependentPizzaStore;

public class Garlic implements Veggies {

    @Override
    public String toString() {
        return "Garlic";
    }
}
