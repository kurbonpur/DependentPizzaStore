package DependentPizzaStore;

public interface Sauce {

    @Override
    public String toString();
}
