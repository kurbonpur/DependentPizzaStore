package DependentPizzaStore;

public interface Clams {

    public String toString();
}
