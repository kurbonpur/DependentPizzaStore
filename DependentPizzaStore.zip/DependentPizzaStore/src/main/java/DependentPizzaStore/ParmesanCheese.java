package DependentPizzaStore;

public class ParmesanCheese implements Cheese {

    @Override
    public String toString() {
        return "Shredded Parmesan";
    }
}
