package DependentPizzaStore;

public interface Cheese {

    public String toString();
}
