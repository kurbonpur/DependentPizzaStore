package DependentPizzaStore;

public interface Veggies {

    @Override
    public String toString();
}
