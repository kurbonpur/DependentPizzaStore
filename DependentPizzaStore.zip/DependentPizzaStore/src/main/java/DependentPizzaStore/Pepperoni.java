package DependentPizzaStore;

public interface Pepperoni {

    @Override
    public String toString();
}
