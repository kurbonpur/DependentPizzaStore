package DependentPizzaStore;

public class Onion implements Veggies {

    @Override
    public String toString() {
        return "Onion";
    }
}
