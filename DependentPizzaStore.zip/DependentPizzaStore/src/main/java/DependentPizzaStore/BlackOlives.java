package DependentPizzaStore;

public class BlackOlives implements Veggies {

    @Override
    public String toString() {
        return "Black Olives";
    }
}
